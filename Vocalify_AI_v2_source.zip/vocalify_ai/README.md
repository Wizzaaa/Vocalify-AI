# Vocalify AI — first functional build

An offline-first Flutter Android project. This milestone adds local recording/playback, WAV instrumental import, YIN-based scale-aware pitch correction (via flutter_audio_fx), offline tone shaping/compression/reverb, stereo mixdown, WAV export, MP3 export (LAME), and local song storage. MusicGen is deliberately not represented as working: Android on-device inference has not yet been integrated or validated.

## Requirements
- Flutter stable (Dart 3.3+)
- Android Studio / Android SDK
- Android device or emulator (a real device is recommended for recording); Android API 26 (Android 8.0) or newer is required by the Auto-Tune audio engine

## Build an APK
1. Install Flutter and Android Studio.
2. In this folder run `flutter create . --org com.vocalify --platforms=android,ios` to generate the native platform folders.
3. Run `flutter pub get`.
4. Connect an Android phone with USB debugging enabled, or start an emulator.
5. Run `flutter run` to test.
6. Build: `flutter build apk --release`.
7. APK output: `build/app/outputs/flutter-apk/app-release.apk`.

## Current workflow
- Record voice as 44.1 kHz mono WAV.
- Import an instrumental WAV from device storage.
- Choose a genre preset (presets currently guide the processing profile; they do not generate music).
- Apply local YIN-based Auto-Tune against a selectable musical key and scale, then local tone shaping, compression, and reverb.
- Mix the processed vocal with an imported instrumental and export WAV + MP3. Vocal-only MP3 export is also supported (mono is duplicated to stereo).
- Recordings and exports are stored in the app documents directory.

## Important limitations
- WAV is the supported input format for instrumental mixing in this build. Convert other formats to PCM WAV first. MP3 is an output format.
- Auto-Tune is integrated through `flutter_audio_fx` (YIN pitch detection and scale-aware correction) and must be auditioned on real singing recordings and tested across target Android devices before claiming studio-grade quality. The package is relatively new; treat it as a dependency requiring validation.
- MP3 export uses `flutter_lame` / LAME. Review LGPL-3.0 obligations before distributing a modified or closed-source application.
- MusicGen is not yet integrated. Meta's published MusicGen model weights are CC-BY-NC 4.0, which is non-commercial; this may conflict with commercial distribution. A genuinely offline Android implementation also needs a compatible mobile inference runtime, a model conversion/quantization pipeline, model-download consent, storage/RAM checks, and device benchmarks. The app does not show a fake Generate button. See https://huggingface.co/facebook/musicgen-small for the model card and license.
- This source project has not been compiled in this environment because the Flutter SDK / Android build toolchain is unavailable here. Build and test it locally before distributing.
- iOS platform scaffolding can be generated, but iOS microphone permissions and device testing still need to be completed before claiming iPhone support.

## Zero-cost and privacy
All audio processing in this milestone runs locally. No accounts, paid APIs, cloud upload, or subscription are used.

## Optional one-click cloud build (free GitHub Actions allowance)
This repository includes `.github/workflows/android-apk.yml`. If you upload the source folder to a GitHub repository, open **Actions → Build Android APK → Run workflow**. When the workflow succeeds, download the `vocalify-ai-android-apk` artifact. GitHub account limits and terms apply; this is only a build runner, not app cloud processing.

## Added dependencies and licensing notes
- `flutter_audio_fx` is MIT-licensed and documents offline file processing plus a YIN-based AutoTune effect. Its Android implementation requires Android API 26+.
- `flutter_lame` bundles LAME and is listed as LGPL-3.0 on pub.dev. Check the exact source distribution and LGPL compliance requirements before distributing the APK.
- MusicGen code and model weights have different licenses: the model weights are CC-BY-NC 4.0. Do not use those weights for commercial purposes without separate permission. This project does not download or redistribute MusicGen weights.
