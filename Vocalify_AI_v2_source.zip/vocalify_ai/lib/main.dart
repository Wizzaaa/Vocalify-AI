import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';
import 'package:flutter_audio_fx/flutter_audio_fx.dart';
import 'package:flutter_lame/flutter_lame.dart';
import 'package:flutter/material.dart';
import 'package:just_audio/just_audio.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:record/record.dart';

void main() => runApp(const VocalifyApp());

const _bg = Color(0xFF090914);
const _panel = Color(0xFF151529);
const _purple = Color(0xFF8B5CF6);
const _blue = Color(0xFF38BDF8);

class VocalifyApp extends StatelessWidget {
  const VocalifyApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Vocalify AI',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: _bg,
          colorScheme: ColorScheme.fromSeed(seedColor: _purple, brightness: Brightness.dark),
          sliderTheme: const SliderThemeData(activeTrackColor: _purple, thumbColor: Colors.white),
          appBarTheme: const AppBarTheme(backgroundColor: _bg, elevation: 0),
        ),
        home: const StudioHome(),
      );
}

class StudioHome extends StatefulWidget {
  const StudioHome({super.key});
  @override
  State<StudioHome> createState() => _StudioHomeState();
}

class _StudioHomeState extends State<StudioHome> {
  final AudioRecorder _recorder = AudioRecorder();
  final AudioPlayer _player = AudioPlayer();
  final List<File> _songs = [];
  File? _vocal;
  File? _instrumental;
  String? _playingPath;
  String _genre = 'Arabic Pop';
  bool _recording = false;
  bool _busy = false;
  String _status = 'Your offline studio is ready';
  double _reverb = 0.18;
  double _strength = 0.55;
  double _tuneStrength = 0.72;
  MusicalKey _tuneKey = MusicalKey.C;
  MusicalScale _tuneScale = MusicalScale.major;
  bool _arabic = false;

  String tr(String en, String ar) => _arabic ? ar : en;

  @override
  void initState() {
    super.initState();
    _loadSongs();
  }

  Future<Directory> _root() async {
    final base = await getApplicationDocumentsDirectory();
    final dir = Directory('${base.path}/Vocalify');
    if (!await dir.exists()) await dir.create(recursive: true);
    return dir;
  }

  Future<void> _loadSongs() async {
    final dir = await _root();
    final files = dir.listSync().whereType<File>().where((f) => f.path.toLowerCase().endsWith('.wav') || f.path.toLowerCase().endsWith('.mp3')).toList()
      ..sort((a, b) => b.lastModifiedSync().compareTo(a.lastModifiedSync()));
    if (mounted) setState(() { _songs..clear()..addAll(files); });
  }

  Future<void> _startRecording() async {
    if (_recording) return;
    final permission = await Permission.microphone.request();
    if (!permission.isGranted) {
      _message(tr('Microphone permission is required.', 'يلزم السماح باستخدام الميكروفون.'));
      return;
    }
    final dir = await _root();
    final path = '${dir.path}/Vocal_${DateTime.now().millisecondsSinceEpoch}.wav';
    try {
      await _recorder.start(const RecordConfig(encoder: AudioEncoder.wav, sampleRate: 44100, numChannels: 1), path: path);
      setState(() { _recording = true; _status = tr('Recording your voice…', 'جارٍ تسجيل صوتك…'); });
    } catch (e) {
      _message('Recording could not start: $e');
    }
  }

  Future<void> _stopRecording() async {
    try {
      final path = await _recorder.stop();
      if (path != null) {
        final f = File(path);
        if (await f.exists() && await f.length() > 44) {
          setState(() { _vocal = f; _status = tr('Recording saved locally', 'تم حفظ التسجيل على الجهاز'); });
          await _loadSongs();
        }
      }
    } finally {
      if (mounted) setState(() => _recording = false);
    }
  }

  Future<void> _importInstrumental() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['wav']);
    if (result?.files.single.path == null) return;
    final f = File(result!.files.single.path!);
    try {
      WavData.read(await f.readAsBytes());
      setState(() { _instrumental = f; _status = tr('Instrumental loaded', 'تم تحميل الموسيقى'); });
    } catch (e) {
      _message(tr('Please choose a PCM 16-bit WAV file.', 'اختر ملف WAV بصيغة PCM وعمق 16 بت.'));
    }
  }

  Future<void> _play(File file) async {
    try {
      if (_playingPath == file.path && _player.playing) {
        await _player.pause();
        setState(() {});
        return;
      }
      await _player.setFilePath(file.path);
      setState(() => _playingPath = file.path);
      await _player.play();
      if (mounted) setState(() {});
    } catch (e) { _message('Could not play this file: $e'); }
  }

  Future<void> _enhanceAndMix() async {
    if (_vocal == null) {
      _message(tr('Record your voice first.', 'سجّل صوتك أولاً.'));
      return;
    }
    setState(() { _busy = true; _status = tr('Processing audio on this device…', 'جارٍ معالجة الصوت على الجهاز…'); });
    try {
      // Run real monophonic pitch correction locally before the tone/dynamics chain.
      // flutter_audio_fx uses YIN pitch detection and a scale-aware AutoTune effect.
      final tempDir = await _root();
      final correctedPath = '${tempDir.path}/Vocalify_Corrected_${DateTime.now().millisecondsSinceEpoch}.wav';
      final tuneEngine = AudioFxEngine();
      await tuneEngine.init();
      tuneEngine.setChain([
        AutoTune(
          key: _tuneKey,
          scale: _tuneScale,
          correctionSpeed: 1.0 - _tuneStrength,
        ),
      ]);
      await tuneEngine.processFile(
        inputPath: _vocal!.path,
        outputPath: correctedPath,
        onProgress: (p) { if (mounted) setState(() => _status = '${tr('Pitch correction', 'تصحيح النغمة')}: ${(p * 100).round()}%'); },
      );
      await tuneEngine.stop();
      final vocalBytes = await File(correctedPath).readAsBytes();
      final vocal = WavData.read(vocalBytes);
      final processed = Dsp.process(vocal, gate: 0.012 + (1 - _strength) * 0.018, reverb: _reverb, intensity: _strength);
      WavData output = processed;
      if (_instrumental != null) {
        final beat = WavData.read(await _instrumental!.readAsBytes());
        output = Dsp.mix(processed, beat);
      }
      final dir = await _root();
      final out = File('${dir.path}/Vocalify_Mix_${DateTime.now().millisecondsSinceEpoch}.wav');
      await out.writeAsBytes(output.encode(), flush: true);
      final mp3 = File(out.path.replaceFirst(RegExp(r'\.wav$', caseSensitive: false), '.mp3'));
      await _encodeMp3(output, mp3);
      await _loadSongs();
      setState(() { _status = tr('Finished! WAV and MP3 saved on this phone.', 'اكتملت المعالجة! تم حفظ WAV وMP3 على الهاتف.'); _playingPath = out.path; });
      _message(tr('Your song was exported as WAV and MP3.', 'تم تصدير الأغنية بصيغتي WAV وMP3.'));
    } catch (e) {
      _message('Audio processing failed: $e');
      setState(() => _status = tr('Processing failed', 'فشلت المعالجة'));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _encodeMp3(WavData audio, File destination) async {
    if (audio.channels < 1 || audio.channels > 2) throw StateError('Unsupported channel count for MP3 export.');
    final encoder = LameMp3Encoder(sampleRate: audio.sampleRate, numChannels: 2);
    final sink = destination.openWrite();
    const chunkFrames = 8192;
    final totalFrames = audio.samples.length ~/ 2;
    for (var start = 0; start < totalFrames; start += chunkFrames) {
      final end = math.min(totalFrames, start + chunkFrames);
      final left = Float64List(end - start);
      final right = Float64List(end - start);
      for (var frame = start; frame < end; frame++) {
        if (audio.channels == 1) {
          left[frame - start] = audio.samples[frame];
          right[frame - start] = audio.samples[frame];
        } else {
          left[frame - start] = audio.samples[frame * 2];
          right[frame - start] = audio.samples[frame * 2 + 1];
        }
      }
      sink.add(await encoder.encode(leftChannel: left, rightChannel: right));
    }
    sink.add(await encoder.flush());
    await sink.flush();
    await sink.close();
  }

  void _message(String text) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));

  @override
  void dispose() {
    _recorder.dispose();
    _player.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isRtl = _arabic;
    return Directionality(textDirection: isRtl ? TextDirection.rtl : TextDirection.ltr,
      child: Scaffold(
        appBar: AppBar(title: Row(children: [
          Container(width: 34, height: 34, decoration: BoxDecoration(borderRadius: BorderRadius.circular(11), gradient: const LinearGradient(colors: [_purple, _blue])), child: const Icon(Icons.graphic_eq, color: Colors.white)),
          const SizedBox(width: 10), const Text('Vocalify', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: .3)),
          const Text(' AI', style: TextStyle(color: _blue, fontWeight: FontWeight.w800)),
          const Spacer(), IconButton(tooltip: 'Language', onPressed: () => setState(() => _arabic = !_arabic), icon: const Icon(Icons.translate)),
        ])),
        body: SafeArea(child: ListView(padding: const EdgeInsets.fromLTRB(18, 8, 18, 28), children: [
          _hero(),
          const SizedBox(height: 20),
          _sectionTitle(tr('Your studio', 'الاستوديو الخاص بك'), tr('Record, enhance and mix — offline', 'سجّل وحسّن وامزج — دون إنترنت')),
          const SizedBox(height: 12),
          _recordCard(),
          const SizedBox(height: 14),
          _genreCard(),
          const SizedBox(height: 14),
          _musicGenStatusCard(),
          const SizedBox(height: 14),
          _processingCard(),
          const SizedBox(height: 14),
          _mixCard(),
          const SizedBox(height: 22),
          _sectionTitle(tr('My songs', 'أغنياتي'), '${_songs.length} ${tr('local WAV files', 'ملفات WAV محفوظة')}'),
          const SizedBox(height: 10),
          if (_songs.isEmpty) _emptySongs() else ..._songs.map(_songTile),
          const SizedBox(height: 18),
          Text(_status, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12)),
          const SizedBox(height: 8),
          const Text('Vocalify AI • Local processing • No account • No cloud', textAlign: TextAlign.center, style: TextStyle(color: Colors.white30, fontSize: 10)),
        ])),
      ),
    );
  }

  Widget _hero() => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF30205C), Color(0xFF151D3B), Color(0xFF111326)]), border: Border.all(color: Colors.white.withValues(alpha: .08))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(tr('YOUR VOICE. YOUR SOUND.', 'صوتك. موسيقاك.'), style: const TextStyle(color: Color(0xFFC4B5FD), letterSpacing: 1.5, fontSize: 10, fontWeight: FontWeight.bold)),
      const SizedBox(height: 9),
      Text(tr('Make your next\nsong sound alive.', 'خلّي أغنيتك\nتنبض بالحياة.'), style: const TextStyle(fontSize: 27, height: 1.12, fontWeight: FontWeight.w800)),
      const SizedBox(height: 14),
      const WaveArt(),
      const SizedBox(height: 12),
      Row(children: [const Icon(Icons.offline_bolt, color: Color(0xFF86EFAC), size: 16), const SizedBox(width: 6), Text(tr('Works offline • Your audio stays on your phone', 'يعمل دون إنترنت • صوتك يبقى على هاتفك'), style: const TextStyle(color: Colors.white70, fontSize: 11))]),
    ]),
  );

  Widget _sectionTitle(String title, String subtitle) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800)), const SizedBox(height: 3), Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11))]);

  Widget _recordCard() => _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const Icon(Icons.mic, color: _blue), const SizedBox(width: 9), Text(tr('1. Record your vocals', '١. سجّل صوتك'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)), const Spacer(), if (_recording) const _LiveDot()]),
    const SizedBox(height: 15),
    Row(children: [Expanded(child: Text(_vocal == null ? tr('No vocal take yet', 'لا يوجد تسجيل صوتي بعد') : _vocal!.uri.pathSegments.last, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white60, fontSize: 12))),
      const SizedBox(width: 8),
      FilledButton.icon(onPressed: _busy ? null : (_recording ? _stopRecording : _startRecording), style: FilledButton.styleFrom(backgroundColor: _recording ? const Color(0xFFEF4444) : _purple), icon: Icon(_recording ? Icons.stop : Icons.fiber_manual_record, size: 17), label: Text(_recording ? tr('Stop', 'إيقاف') : tr('Record', 'تسجيل'))),
    ]),
    if (_vocal != null) Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () => _play(_vocal!), icon: const Icon(Icons.play_arrow), label: Text(tr('Listen to take', 'استمع للتسجيل')))),
  ]));

  Widget _genreCard() => _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const Icon(Icons.library_music, color: _purple), const SizedBox(width: 9), Text(tr('2. Choose your style', '٢. اختر اللون الموسيقي'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15))]),
    const SizedBox(height: 12),
    Wrap(spacing: 7, runSpacing: 7, children: ['Arabic Pop', 'Egyptian Shaabi', 'Egyptian Pop', 'Tarab', 'Rap', 'Hip-Hop', 'R&B', 'Pop', 'Rock', 'Acoustic'].map((g) => ChoiceChip(label: Text(g, style: const TextStyle(fontSize: 11)), selected: _genre == g, onSelected: (_) => setState(() => _genre = g), selectedColor: _purple.withValues(alpha: .35), backgroundColor: const Color(0xFF202039), side: BorderSide(color: _genre == g ? _purple : Colors.white10))).toList()),
    const SizedBox(height: 6), const Text('Style selection is a processing preset only; it does not generate an instrumental.', style: TextStyle(color: Colors.white38, fontSize: 10)),
  ]));

  Widget _musicGenStatusCard() => _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const Icon(Icons.auto_awesome, color: _purple), const SizedBox(width: 9), Text(tr('AI instrumental generation', 'توليد موسيقى بالذكاء الاصطناعي'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)), const Spacer(), const Text('PLANNED', style: TextStyle(color: Color(0xFFFBBF24), fontSize: 9, fontWeight: FontWeight.bold))]),
    const SizedBox(height: 8),
    Text(tr('MusicGen is not bundled or enabled in this build. Its published weights are CC BY-NC 4.0 (non-commercial), and a tested Android inference runtime plus model storage checks are still required. Import your own WAV instrumental for now.', 'MusicGen غير مدمج أو مفعّل في هذا الإصدار. أوزانه المنشورة بترخيص CC BY-NC 4.0 للاستخدام غير التجاري، وما زلنا بحاجة إلى محرك تشغيل أندرويد مُختبَر وفحص مساحة التخزين والذاكرة. يمكنك استيراد موسيقى WAV حاليًا.'), style: const TextStyle(color: Colors.white54, fontSize: 11, height: 1.45)),
  ]));

  Widget _processingCard() => _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const Icon(Icons.auto_awesome, color: _blue), const SizedBox(width: 9), Text(tr('3. Vocal enhancement', '٣. تحسين الصوت'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)), const Spacer(), const _LocalTag()]),
    const SizedBox(height: 14),
    _sliderRow(tr('Auto-Tune strength', 'قوة تصحيح النغمة'), _tuneStrength, (v) => setState(() => _tuneStrength = v)),
    Row(children: [Expanded(child: DropdownButtonFormField<MusicalKey>(value: _tuneKey, decoration: InputDecoration(labelText: tr('Key', 'المقام')), items: MusicalKey.values.map((k) => DropdownMenuItem(value: k, child: Text(k.name))).toList(), onChanged: _busy ? null : (v) { if (v != null) setState(() => _tuneKey = v); })), const SizedBox(width: 12), Expanded(child: DropdownButtonFormField<MusicalScale>(value: _tuneScale, decoration: InputDecoration(labelText: tr('Scale', 'السلم')), items: MusicalScale.values.map((s) => DropdownMenuItem(value: s, child: Text(s.name))).toList(), onChanged: _busy ? null : (v) { if (v != null) setState(() => _tuneScale = v); }))]),
    const SizedBox(height: 8),
    _sliderRow(tr('Enhancement strength', 'قوة التحسين'), _strength, (v) => setState(() => _strength = v)),
    _sliderRow(tr('Reverb / room', 'الصدى / مساحة الصوت'), _reverb, (v) => setState(() => _reverb = v)),
    Text(tr('Real offline YIN-based pitch correction snaps sung notes to the selected musical scale. WAV + MP3 export uses local processing.', 'تصحيح نغمة حقيقي محلي يعتمد على YIN ويضبط النغمات على السلم المختار. التصدير WAV وMP3 محلي.'), style: const TextStyle(color: Colors.white38, fontSize: 10, height: 1.4)),
  ]));

  Widget _mixCard() => _card(Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Row(children: [const Icon(Icons.multitrack_audio, color: _purple), const SizedBox(width: 9), Text(tr('4. Add instrumental & export', '٤. أضف الموسيقى وصدّر'), style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15))]),
    const SizedBox(height: 12),
    Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(14)), child: Row(children: [const Icon(Icons.music_note, color: _blue), const SizedBox(width: 9), Expanded(child: Text(_instrumental?.uri.pathSegments.last ?? tr('No instrumental selected (vocal-only export)', 'لم يتم اختيار موسيقى (تصدير الصوت فقط)'), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: Colors.white70))), IconButton(onPressed: _busy ? null : _importInstrumental, icon: const Icon(Icons.add_circle, color: _blue))])),
    const SizedBox(height: 12),
    SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _busy ? null : _enhanceAndMix, style: FilledButton.styleFrom(backgroundColor: _purple, padding: const EdgeInsets.symmetric(vertical: 14)), icon: _busy ? const SizedBox(width: 17, height: 17, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.auto_fix_high), label: Text(_busy ? tr('Processing…', 'جارٍ التنفيذ…') : tr('Auto-Tune, mix & export WAV + MP3', 'صحّح النغمة وامزج وصدّر WAV وMP3')))),
  ]));

  Widget _sliderRow(String label, double value, ValueChanged<double> onChanged) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12))), Text('${(value * 100).round()}%', style: const TextStyle(color: _blue, fontSize: 11))]), Slider(value: value, onChanged: _busy ? null : onChanged)]);

  Widget _emptySongs() => _card(const Row(children: [Icon(Icons.library_music_outlined, color: Colors.white38), SizedBox(width: 10), Expanded(child: Text('Your saved recordings and mixes will appear here.', style: TextStyle(color: Colors.white54, fontSize: 12)))]));
  Widget _songTile(File f) => Padding(padding: const EdgeInsets.only(bottom: 8), child: _card(Row(children: [const Icon(Icons.audio_file, color: _blue), const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(f.uri.pathSegments.last, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w600)), Text(_sizeLabel(f), style: const TextStyle(fontSize: 10, color: Colors.white38))])), IconButton(onPressed: () => _play(f), icon: Icon(_playingPath == f.path && _player.playing ? Icons.pause_circle : Icons.play_circle, color: _purple, size: 27))])));
  String _sizeLabel(File f) { try { return '${(f.lengthSync() / (1024 * 1024)).toStringAsFixed(1)} MB'; } catch (_) { return 'WAV'; } }
  Widget _card(Widget child) => Container(padding: const EdgeInsets.all(15), decoration: BoxDecoration(color: _panel, borderRadius: BorderRadius.circular(19), border: Border.all(color: Colors.white.withValues(alpha: .06))), child: child);
}

class _LocalTag extends StatelessWidget { const _LocalTag(); @override Widget build(BuildContext context) => Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4), decoration: BoxDecoration(color: const Color(0xFF14532D).withValues(alpha: .35), borderRadius: BorderRadius.circular(20)), child: const Text('ON-DEVICE', style: TextStyle(color: Color(0xFF86EFAC), fontSize: 8, fontWeight: FontWeight.bold))); }
class _LiveDot extends StatelessWidget { const _LiveDot(); @override Widget build(BuildContext context) => const Row(children: [Icon(Icons.circle, color: Colors.redAccent, size: 8), SizedBox(width: 5), Text('REC', style: TextStyle(color: Colors.redAccent, fontSize: 10, fontWeight: FontWeight.bold))]); }
class WaveArt extends StatelessWidget { const WaveArt({super.key}); @override Widget build(BuildContext context) { const heights = [12, 22, 31, 17, 39, 25, 46, 18, 32, 52, 28, 42, 18, 35, 25, 47, 19, 34, 12, 27, 42, 18, 31, 14, 24, 38, 18, 29, 12, 22]; return SizedBox(height: 55, child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, crossAxisAlignment: CrossAxisAlignment.center, children: heights.map((h) => Container(width: 4, height: h.toDouble(), decoration: BoxDecoration(borderRadius: BorderRadius.circular(4), gradient: const LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [_blue, _purple])))).toList())); } }

class WavData {
  WavData(this.samples, this.sampleRate, this.channels);
  final List<double> samples;
  final int sampleRate;
  final int channels;

  static WavData read(Uint8List bytes) {
    if (bytes.length < 44 || String.fromCharCodes(bytes.sublist(0, 4)) != 'RIFF' || String.fromCharCodes(bytes.sublist(8, 12)) != 'WAVE') throw const FormatException('Not a RIFF WAV file');
    final d = ByteData.sublistView(bytes);
    int? fmt, data, dataLen;
    var pos = 12;
    while (pos + 8 <= bytes.length) {
      final id = String.fromCharCodes(bytes.sublist(pos, pos + 4));
      final len = d.getUint32(pos + 4, Endian.little);
      if (id == 'fmt ') fmt = pos + 8;
      if (id == 'data') { data = pos + 8; dataLen = len; break; }
      pos += 8 + len + (len.isOdd ? 1 : 0);
    }
    if (fmt == null || data == null || dataLen == null || fmt + 16 > bytes.length) throw const FormatException('Missing WAV chunks');
    final format = d.getUint16(fmt, Endian.little), channels = d.getUint16(fmt + 2, Endian.little), rate = d.getUint32(fmt + 4, Endian.little), bits = d.getUint16(fmt + 14, Endian.little);
    if (format != 1 || bits != 16 || channels < 1 || channels > 2 || rate < 8000) throw const FormatException('Only PCM 16-bit mono/stereo WAV is supported');
    final end = math.min(bytes.length, data + dataLen);
    final count = (end - data) ~/ 2;
    final samples = List<double>.generate(count, (i) => d.getInt16(data! + i * 2, Endian.little) / 32768.0, growable: false);
    return WavData(samples, rate, channels);
  }

  Uint8List encode() {
    final out = Uint8List(44 + samples.length * 2);
    final d = ByteData.sublistView(out);
    void tag(int at, String s) { for (var i = 0; i < 4; i++) { out[at + i] = s.codeUnitAt(i); } }
    tag(0, 'RIFF'); d.setUint32(4, out.length - 8, Endian.little); tag(8, 'WAVE'); tag(12, 'fmt ');
    d.setUint32(16, 16, Endian.little); d.setUint16(20, 1, Endian.little); d.setUint16(22, channels, Endian.little); d.setUint32(24, sampleRate, Endian.little);
    d.setUint32(28, sampleRate * channels * 2, Endian.little); d.setUint16(32, channels * 2, Endian.little); d.setUint16(34, 16, Endian.little); tag(36, 'data'); d.setUint32(40, samples.length * 2, Endian.little);
    for (var i = 0; i < samples.length; i++) { final v = (samples[i].clamp(-1.0, 1.0) * 32767).round(); d.setInt16(44 + i * 2, v, Endian.little); }
    return out;
  }
}

class Dsp {
  static WavData process(WavData input, {required double gate, required double reverb, required double intensity}) {
    final x = input.samples;
    final low = List<double>.filled(x.length, 0);
    final out = List<double>.filled(x.length, 0);
    final alpha = 1 - math.exp(-2 * math.pi * 180 / input.sampleRate);
    var lp = 0.0;
    final delay = List<double>.filled((input.sampleRate * .19).round().clamp(1, input.sampleRate), 0);
    var dp = 0;
    var envelope = 0.0;
    for (var i = 0; i < x.length; i++) {
      final s = x[i];
      lp += alpha * (s - lp);
      low[i] = lp;
      final high = s - lp;
      var y = low[i] * (1 + .18 * intensity) + high * (1 + .28 * intensity);
      envelope = envelope * .995 + s.abs() * .005;
      if (envelope < gate) y *= .18;
      final a = y.abs();
      if (a > .72) y = y.sign * (.72 + (a - .72) / (1 + (a - .72) * 5));
      final echo = delay[dp];
      delay[dp] = y + echo * .22;
      dp = (dp + 1) % delay.length;
      out[i] = (y * (1 - reverb * .28) + echo * reverb * .28).clamp(-1.0, 1.0);
    }
    return WavData(out, input.sampleRate, input.channels);
  }

  static WavData mix(WavData vocal, WavData instrumental) {
    final rate = vocal.sampleRate;
    final framesV = vocal.samples.length ~/ vocal.channels;
    final framesB = instrumental.samples.length ~/ instrumental.channels;
    final frames = math.max(framesV, ((framesB * rate) / instrumental.sampleRate).round());
    final out = List<double>.filled(frames * 2, 0);
    double sampleAt(WavData w, int frame, int channel) {
      final sourceFrame = (frame * w.sampleRate / rate).floor();
      final total = w.samples.length ~/ w.channels;
      if (sourceFrame < 0 || sourceFrame >= total) return 0;
      final c = w.channels == 1 ? 0 : channel;
      return w.samples[sourceFrame * w.channels + c];
    }
    for (var i = 0; i < frames; i++) {
      for (var c = 0; c < 2; c++) {
        final v = sampleAt(vocal, i, c) * .92;
        final b = sampleAt(instrumental, i, c) * .62;
        final sum = v + b;
        out[i * 2 + c] = (sum / (1 + sum.abs() * .22)).clamp(-1.0, 1.0);
      }
    }
    return WavData(out, rate, 2);
  }
}
